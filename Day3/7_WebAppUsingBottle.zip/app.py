# from bottle import route, run

# # Data Coming from DB
# cars = [{'name': 'Audi', 'price': 52642},
#         {'name': 'Mercedes', 'price': 57127},
#         {'name': 'Skoda', 'price': 9000},
#         {'name': 'Volvo', 'price': 29000},
#         {'name': 'Bentley', 'price': 350000},
#         {'name': 'Citroen', 'price': 21000},
#         {'name': 'Hummer', 'price': 41400},
#         {'name': 'Volkswagen', 'price': 21600}]

# @route('/')
# def hello():
#     return "Hello from Bottle Web Application"

# @route('/cars')
# def getCars():
#     return dict(data=cars)

# run(host='localhost', port=8080, debug=True, reloader=True)

# --------------------------------------------------------------------------------

from bottle import route, run, static_file, HTTPResponse, template


def getcars():
    # Data coming from the DB
    cars = [{'name': 'Audi', 'price': 52642},
            {'name': 'Mercedes', 'price': 57127},
            {'name': 'Skoda', 'price': 9000},
            {'name': 'Volvo', 'price': 29000},
            {'name': 'Bentley', 'price': 350000},
            {'name': 'Citroen', 'price': 21000},
            {'name': 'Hummer', 'price': 41400},
            {'name': 'Volkswagen', 'price': 21600}]

    return cars


@route('/<filepath:path>')
def serve_static(filepath):
    return static_file(filepath, root="./public")


@route('/cars')
def cars():
    data = getcars()

    if data:
        return template("show_cars", cars=data)
    else:
        return HTTPResponse(status=204)


run(host='localhost', port=8080, debug=True, reloader=True)
