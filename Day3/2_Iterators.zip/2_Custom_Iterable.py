class MyRange:
    def __init__(self, limit):
        self._limit = limit

    def __iter__(self):
        self._start = 1
        return self

    def __next__(self):
        start = self._start

        if(start > self._limit):
            raise StopIteration

        self._start = start+1
        return start


# for i in MyRange(5):
#     print(i)

print(list(range(20)))
print(list(MyRange(20)))
