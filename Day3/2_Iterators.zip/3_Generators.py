# def idGenerator():
#     yield 1
#     yield 2
#     yield 3

# # print(idGenerator())

# x = idGenerator()

# # print(dir(x))
# print(next(x))
# print(next(x))
# print(next(x))
# print(next(x))

# ------------------------------------------

class Queue:
    def __init__(self):
        self._children = []

    def push(self, data):
        self._children.append(data)

    def pop(self):
        return self._children.pop(0)

    def __iter__(self):
        return iter(self._children)

    # def __iter__(self):
    #     for i in self._children:
    #         yield i


numbersQ = Queue()

numbersQ.push(10)
numbersQ.push(20)
numbersQ.push(30)

# print(numbersQ.pop())
# print(numbersQ.pop())
# print(numbersQ.pop())

for n in numbersQ:
    print(n)
