# def add(a, b):
#     return a+b

# print(add)

# def add(a, b, c):
#     return a+b+c

# print(add)

# print(locals())
# print(add(2, 3))
# print(add(2, 3, 4))

# --------------------------------------------------
registry = {}


class MultipleMethod(object):
    def __init__(self, name):
        self.name = name
        self.typemap = {}

    def __call__(self, *args):
        types = tuple(arg.__class__ for arg in args)
        function = self.typemap.get(types)
        if function is None:
            raise TypeError("No Function Implementation Found")
        return function(*args)

    def register(self, types, function):
        self.typemap[types] = function


def overload(*types):
    def register(function):
        name = function.__name__
        mm = registry.get(name)
        if mm is None:
            mm = registry[name] = MultipleMethod(name)
        mm.register(types, function)
        return mm
    return register


@overload(int, int)
def add(a, b):
    return a+b


@overload(int, int, int)
def add(a, b, c):
    return a+b+c


print(add(2, 3))
print(add(2, 3, 4))
