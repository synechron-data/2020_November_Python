# Create a class named BankAccount with two attributes accNumber, accHolderName and bankName, 
# instantiate 2 objects by passing values and access the values by creating 3 accessor methods 

# class BankAccount:
#     def __init__(self, accNo, accName, bankName):
#         self._accNumber = accNo
#         self._accHolderName = accName
#         self._bankName = bankName

#     def getAccountNumber(self):
#         return self._accNumber

#     def getAccountHolderName(self):
#         return self._accHolderName

#     def getBankName(self):
#         return self._bankName

# a1 = BankAccount(1, "Manish", "ICICI")
# print("Bank Name: ", a1.getBankName())
# print("Account Number: ", a1.getAccountNumber())
# print("Account Holder Name: ", a1.getAccountHolderName())

# a2 = BankAccount(2, "Abhijeet", "ICICI")
# print("\nBank Name: ", a2.getBankName())
# print("Account Number: ", a2.getAccountNumber())
# print("Account Holder Name: ", a2.getAccountHolderName())

# -------------------------------------------------------------------------------

class BankAccount:
    _bankName = "ICICI"

    def __init__(self, accNo, accName):
        self._accNumber = accNo
        self._accHolderName = accName

    def getAccountNumber(self):
        return self._accNumber

    def getAccountHolderName(self):
        return self._accHolderName

    def getBankName(self):
        return BankAccount._bankName

    @staticmethod
    def setBankName(value):
        BankAccount._bankName = value

BankAccount.setBankName("HDFC")

a1 = BankAccount(1, "Manish")
print("Bank Name: ", a1.getBankName())
print("Account Number: ", a1.getAccountNumber())
print("Account Holder Name: ", a1.getAccountHolderName())

a2 = BankAccount(2, "Abhijeet")
print("\nBank Name: ", a2.getBankName())
print("Account Number: ", a2.getAccountNumber())
print("Account Holder Name: ", a2.getAccountHolderName())
