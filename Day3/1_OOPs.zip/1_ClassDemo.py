# class Employee:
#     pass

# class Employee:
#     def __init__(self, id):
#         self._id = id

#     def __repr__(self):
#         return f"Employee Id is {self._id}"

#     def __str__(self):
#         return f"String Employee Id is {self._id}"


# a = int(10)
# print(a)
# print(type(a))

# e = Employee(1)
# print(e)                # print(str(e))
# print(type(e))
# print(str(e))            # print(str(e))
# print(e._id)

# -------------------------------------------------------

# class Employee:
#     # def __new__(cls):
#     #     print("Creating Employee Instance")
#     #     return super(Employee, cls).__new__(cls)

#     def __init__(self):
#         print("Employee Init is called")

# e = Employee()
# -------------------------------------------------------

# class Employee:
#     def __init__(self, id=0, name="NA", desig="NA", sal=0):
#         self._id = id
#         self._name = name
#         self._designation = desig
#         self._salary = sal

#     def getId(self):
#         return self._id

#     def getName(self):
#         return self._name

#     def getDesignation(self):
#         return self._designation

#     def getSalary(self):
#         return self._salary

#     def setSalary(self, value):
#         if(value <= 0):
#             raise ValueError("Salary cannot 0 or negative number")
#         self._salary = value

#     def __eq__(self, obj):
#         return self._salary == obj._salary

#     def __gt__(self, obj):
#         return self._salary > obj._salary

#     def __lt__(self, obj):
#         return self._salary < obj._salary

#     def __add__(self, obj):
#         return self._salary + obj._salary

# e = Employee(1, "Manish", "Trainer", 12345)
# print("Id: ", e.getId())
# print("Name: ", e.getName())
# print("Designation: ", e.getDesignation())
# print("Salary: ", e.getSalary())

# try:
#     e.setSalary(0)
#     print("Salary: ", e.getSalary())
# except Exception as exp:
#     print(exp)

# ----------------------------------------------------------------------
from functools import total_ordering

@total_ordering
class Employee:
    def __init__(self, id=0, name="NA", desig="NA", sal=0):
        self._id = id
        self._name = name
        self._designation = desig
        self._salary = sal

    def getId(self):
        return self._id

    def getName(self):
        return self._name

    def getDesignation(self):
        return self._designation

    def getSalary(self):
        return self._salary

    def setSalary(self, value):
        if(value <= 0):
            raise ValueError("Salary cannot 0 or negative number")
        self._salary = value

    def __eq__(self, obj):
        return self._salary == obj._salary

    def __gt__(self, obj):
        return self._salary > obj._salary

    def __add__(self, obj):
        return self._salary + obj._salary


e1 = Employee(1, "Manish", "Trainer", 12345)
print("Id: ", e1.getId())
print("Name: ", e1.getName())
print("Designation: ", e1.getDesignation())
print("Salary: ", e1.getSalary())

e2 = Employee(2, "Abhijeet", "Consultant", 22345)
print("\nId: ", e2.getId())
print("Name: ", e2.getName())
print("Designation: ", e2.getDesignation())
print("Salary: ", e2.getSalary())

print(e1 == e2)
print(e1 > e2)
print(e1 >= e2)
print("Combined Salary: ", e1 + e2)

# print(e1())     # You should implement __call__ in your class