# int       Signed & Unlimited precision

# print(10)       # decimal (base 10)
# print(0b10)       # binary (base 2)
# print(0o10)       # octal (base 8)
# print(0x10)       # hex (base 16)
# print(type(0x10))       # hex (base 16)

# print(int(3.5))
# print(int(-3.5))
# print(int(456))
# print(int("1010"))
# print(int("1010",2))
# print(int("1010",8))
# print(int("1010",4))

# print(int(True)+10)

# float  Double Precision (64 bit)
# print(3.125)
# print(type(3.125))
# print(300000000000000000000000000000000000000000000000000000000000000000000000000000000000.125)
# print(3e8)
# print(float(7))

# bool
# a = True
# # print(type(a))

# print(bool(1))
# print(bool(0))
# print(bool(-1))
# print(bool(""))
# print(bool(None))
# print(bool("Manish"))

# ------------------------------------

a = "1001"
# print(a+1)    # TypeError: can only concatenate str (not "int") to str

print(a+"1")
print(int(a)+1)
print(int(a, 2))
print(int(a, 2)+1)
