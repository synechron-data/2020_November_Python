# from itertools import permutations, combinations

# data = 'ABCD'

# result1 = permutations(data, 2)
# print(list(result1))

# result2 = combinations(data, 2)
# print(list(result2))

# ---------------------------------------------------------
# from itertools import groupby
# colors = ['blue', 'red', 'blue', 'yellow', 'blue', 'red']

# # r1 = [(i, len(list(c))) for i, c in groupby(colors)]
# # r1 = [(i, len(list(c))) for i, c in groupby(sorted(colors))]
# r1 = [(i, len(list(c))) for i, c in groupby(sorted(colors, reverse=True))]

# print(r1)

# ---------------------------------------------------------
# from itertools import accumulate
# data = [1, 2, 3, 4, 5]

# result = accumulate(data)
# print(list(result))

# ---------------------------------------------------------
# from itertools import accumulate
# from operator import mul
# data = [1, 2, 3, 4, 5]

# result = accumulate(data, mul)
# print(list(result))

# ---------------------------------------------------------
# from itertools import accumulate
# data = [5, 2, 6, 4, 5, 9, 1]

# result = accumulate(data, max)
# print(list(result))

# ---------------------------------------------------------
import time
import operator

data1 = [1, 2, 3, 4]
data2 = [5, 6, 7, 8]

t1 = time.time()
result1 = []
for i in range(len(data1)):
    result1.append(data1[i]* data2[i])
t2 = time.time()
print("Result 1: ", result1)
print("\nTime taken by for loop: %.16f" % (t2 - t1))

t1 = time.time()
result2 = list(map(operator.mul, data1, data2))
t2 = time.time()

print("Result 2: ", result2)
print("\nTime taken by map function: %.16f" % (t2 - t1))
