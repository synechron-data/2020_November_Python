# a
# print(a)          # RuntimeError: Bad magic number in .pyc file

# a = None
# print(a)
# print(type(a))

# a = 10
# print(a)
# print(type(a))

# # a = "Synechron"
# a = 10.5
# print(a)
# print(type(a))

# a, b, c = 10, 20.5, "Synechron"
# a, b, c = 10, 20.5          # ValueError: not enough values to unpack
# a = b = c = 10

# print(a)
# print(type(a))

# print(b)
# print(type(b))

# print(c)
# print(type(c))

# a = {1,2,3}
# print(a)
# print(type(a))

# a = []
# print(a)
# print(type(a))

# --------------------------------------------------------

# a = "Synechron"
# a = 10

# print(a)
# print(type(a))

# del a
# print(a)            # NameError: name 'a' is not defined
# print(type(a))

# --------------------------------------------------------

# x = "Synechron"
# y = "Synechron"

# print(x)
# print(y)

# print(type(x))
# print(type(y))

# print(id(x))
# print(id(y))
# print(x is y)

# x = "Manish"
# print(x)
# print(y)

# print(type(x))
# print(type(y))

# print(id(x))
# print(id(y))
# print(x is y)

x = 10
print(x)
print(type(x))
print(id(x))

y = x
print(y)
print(type(y))
print(id(y))

del x
# x = 20
# print(x)
# print(type(x))
# print(id(x))

print(y)
print(type(y))
print(id(y))