data = [2, 4, 3, 1, 1, 4]

# Write a logic to create a list with unique numbers from the above input list
# Expected Output - [2, 4, 3, 1]

# unique_data = list()

# for value in data:
#     if(value not in unique_data):
#         unique_data.append(value)

# print(unique_data)

# -----------------------------------------
# Expected Output Ordered - [1, 2, 3, 4]
# unique_data = set()

# for value in data:
#     unique_data.add(value)

# unique_list = list(unique_data)
# print(unique_list)

# ---------------------------
# unique_list = list(set(data))
# print(unique_list)

# Write a logic to create a dictionary with number as the key and count as the value on the above input list
# Expected Output - {2: 1, 4: 2, 3: 1, 1: 2}

# result = dict()

# for i in data:
#     if i in result:
#         result[i] = result[i]+1
#     else:
#         result[i] = 1

# print(result)

# ---------------------------------------

# result = dict()

# for i in set(data):
#     result[i] = data.count(i)

# print(result)

# ---------------------------------------
# List Comprehension - [exp(item) for item in iterable]
# Dict Comprehension - {exp(item) for item in iterable}

# result = dict((i, data.count(i)) for i in set(data))
# result = {i: data.count(i) for i in set(data)}

# print(result)

# ----------------------------------------
from collections import Counter
result = dict(Counter(data))
print(result)
