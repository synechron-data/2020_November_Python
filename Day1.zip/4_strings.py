# name1 = "Synechron"
# name2 = 'Pune Phase 3'
# name3 = 'A'

# print(name1)
# print(type(name1))

# print(name2)
# print(type(name2))

# print(name3)
# print(type(name3))

# name4 = """Synechron
#     Pune Phase 3"""
# print(name4)
# print(type(name4))

# name5 = '''Synechron
#     Pune Phase 3'''
# print(name5)
# print(type(name5))

# message = '"Hello"'
# # print(message)

# print(message[0])
# print(message[1])
# print(message[1:4])

# fname = "Manish"
# lname = "Sharma"
# # message = "Hello, " + fname + " " + lname
# # message = "Hello, {} {}".format(fname, lname)

# # f-string
# message = f"Hello, {fname} {lname}"

# print(message)

price = 49
print("Price is: {}".format(price))
print("Price is: {:.2f}".format(price))
print(f"Price is: {price:.2f}")
