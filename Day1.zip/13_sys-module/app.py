# This module provides access to some variables used or maintained by the
# interpreter and to functions that interact strongly with the interpreter.

import sys

# print(sys.builtin_module_names)
# print(sys.path)
# print(sys.version)
# print(sys.maxsize)

# print(sys.argv)
print(f"Hello {sys.argv[1]}, Welcome to {sys.argv[2]}")
# py app.py Manish Python_World
