print("Hello World!")
print(len("Hello World!"))
print(bin(16))