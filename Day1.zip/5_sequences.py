# ----------------------------------------------- List (Like Array)
# data = list()
# data = [1, 2, 3, 4, 5, "Pune"]
# print(data)
# print(type(data))

# print(data[0])
# print(data[1:4])

# print(data)
# print(id(data))
# # data.append(6)
# # data[0] = "Changed"
# # data = [1, 2]
# print(data)
# print(id(data))

# for a in data:
#     print(a)
# print("Inside")

# print("Outside")
# ----------------------------------------------------- Operation/Functions
# data = [1, 2, 5, 5, 3, 4, 5]
# print(data)
# # print(data[1:40])
# # print(data[40])             # IndexError: list index out of range
# print(data[1:40:2])             # Slice sequence from index 1 to 40 with step 2
# print(data + [6, 7])
# print(data * 3)

# print(3 in data)
# print(30 in data)
# print(30 not in data)

# print(min(data))
# print(max(data))
# print(len(data))

# print(data.count(5))
# data.clear()
# print(data)

# ----------------------------------------------- Tuple (collection which is ordered and unchangeable)

# data = tuple()
# data = tuple()
# data = (1, 2, 3, 4, 5, "Pune")
# # print(data)
# # print(type(data))

# print(data[0])
# print(data[1:40])

# # data.append(6)          # AttributeError: 'tuple' object has no attribute 'append'
# # data[0] = "Changed"     # TypeError: 'tuple' object does not support item assignment

# # print(data)

# for a in data:
#     print(a)

# ----------------------------------------------- Set (Unordered collection data type that is iterable, mutable and has no duplicate elements.)
# data = set()
# data = {1, 2, 3, 4, 5, "Pune",1, 2, 3, 4, 5, "Pune"}
# print(data)
# print(type(data))

# data.add(6)
# data.add(6)

# for a in data:
#     print(a)

# ---------------------------------------------- Dictionary (Unordered collection of data values, used to store data values like a map)
# data = dict()
# data = {
#     "Manish": 999999999,
#     "Abhijeet": 9999988888,
#     "Ramakant": 8888877777
# }

# data["Manish"] = 1111111111
# data["Sumeet"] = 2222222222

# print(data["Manish"])
# print(data.get("Manish"))

# print(data)
# print(type(data))

# for a in data:
#     print(a)

# for a in data.items():
#     print(a)

# for a in data.keys():
#     print(a)

# for a in data.values():
#     print(a)

# ------------------------------------------------ Range
# nRange = range(0, 10)
# print(nRange)
# print(type(nRange))

# data = list(nRange)
# data = tuple(nRange)
# data = set(nRange)

# print(data)
# print(type(data))

# for a in nRange:
#     print(a)

# ----------------------------------------------- Input and Creating a dynamic list

numberList = []

n = int(input("Enter number of items: "))

for i in range(n):
    inp = int(input("Enter a number: "))
    numberList.append(inp)

print(numberList)
