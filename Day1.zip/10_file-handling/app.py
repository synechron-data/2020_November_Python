# # r, w, a
# # r+, w+, a+
# # rb, wb, ab
# # rb+, wb+, ab+

# # fo = open("file1.txt", "w+")
# # print("Name of the file ", fo.name)
# # print("Mode of the file ", fo.mode)
# # fo.close()
# # print("Closed Status of the file ", fo.closed)

# input = "This is just an example of File Write.\nUsing Python"
# # fo = open("file1.txt", "w+")
# # fo.write(input)

# fo = open("file1.txt", "wb+")
# binp = bytearray(input, "utf-8")
# fo.write(binp)

# position = fo.tell()
# print("Current Cursor position", position)

# position = fo.seek(0)
# print("Current Cursor position", position)

# # str = fo.read()
# # str = fo.read(10)
# # str = fo.readline()
# # str = fo.readlines()

# # print(str)

# for line in fo.readlines():
#     print(line)
#     print(type(line))

# fo.close()

# -------------------------------------------------------------
import json

# employee = {
#     "name": "Manish",
#     "age": 38,
#     "city": "Pune"
# }
# print(employee)
# print(type(employee))

# Serialize obj to a JSON formatted str.
# y = json.dumps(employee)
# print(y)
# print(type(y))

# fo = open('data.json', "w")
# json.dump(employee, fo)
# fo.close()

# fo = open('data.json', "r")
# # Deserialize fp (a .read()-supporting file-like object containing a JSON document) to a Python object.
# data = json.load(fo)

# print(data)
# print(type(data))


# --------------------------------

# fo = open('posts.json', "r")
# posts = json.load(fo)

# print(posts)
# print(type(posts))

fo = open('user.json', "r")
user = json.load(fo)

print(user)
print(type(user))
