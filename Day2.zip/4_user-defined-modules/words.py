print("\n\nWords.py file is loaded.......\n\n")

# import re
# from urllib.request import urlopen

# with urlopen('http://sixty-north.com/c/t.txt') as story:
#     responseString = story.read().decode('utf-8')
#     story_words = re.split(r'\s', responseString)

# print(story_words)

# ----------------------------------------------------------
import re
from urllib.request import urlopen


def fetch_words():
    with urlopen('http://sixty-north.com/c/t.txt') as story:
        responseString = story.read().decode('utf-8')
        story_words = re.split(r'\s', responseString)

    return story_words


# print(__name__)

if __name__ == "__main__":
    print(fetch_words())