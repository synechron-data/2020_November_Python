import re
from urllib.request import urlopen


def fetch_words():
    print("Fetch Words called from Check Folder")
    with urlopen('http://sixty-north.com/c/t.txt') as story:
        responseString = story.read().decode('utf-8')
        story_words = re.split(r'\s', responseString)

    return story_words


# print(__name__)

if __name__ == "__main__":
    print(fetch_words())
