# import words
# result = words.fetch_words()
# print(result)

# from words import fetch_words
# result = fetch_words()
# print(result)

# # ---------------------------------------------------
# import words
# import check.words

# result1 = check.words.fetch_words()
# print(result1)

# result2 = words.fetch_words()
# print(result2)

# # ---------------------------------------------------
# from words import fetch_words
# from check.words import fetch_words

# result1 = fetch_words()
# print(result1)

# result2 = fetch_words()
# print(result2)

# ---------------------------------------------------
# from words import fetch_words as f1
# from check.words import fetch_words as f2

# result1 = f1()
# print(result1)

# result2 = f2()
# print(result2)

# -----------------------------------------------------
# Module is loaded once and cached for next time use
import words
import words
import words