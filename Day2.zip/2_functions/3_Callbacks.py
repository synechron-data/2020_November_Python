# a = 10
# print(a)
# print(type(a))

# def hello():
#     pass

# print(hello)
# print(type(hello))

# If Function is considered as datatype, following should be applicable

# Can we create a variable of type int, inside a function?
# If yes, we can also create a variable of type function, inside a function (Nested Function)

# Can we return a variable of type int, from a function?
# If yes, we can also return a variable of type function, from a function (Creating Closures)

# Can we pass a variable of type int, to a function?
# If yes, we can also pass a variable of type function, to a function (Callbacks)

# def average(*numbers):
#     sum = 0
#     for n in numbers:
#         sum += n

#     if len(numbers):
#         return sum/len(numbers)
#     else:
#         return sum

# result = average(1, 2, 3, 4, 5, 6, 7, 8, 9)
# print(result)

# ---------------------------------------------- Fn Passed as argument to another Fn
# Dev 1
import operator
import functools


def average(callback, *numbers):
    sum = 0
    for n in numbers:
        sum += n

    if len(numbers):
        callback(sum/len(numbers))
    else:
        callback(sum)


# Dev 2
def printResult(result):
    print("Result is: ", result)


# average(printResult, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# ------------------------------------------------- map function

# numList = [1, 2, 3, 4, 5, 6, 7, 8, 9]


# def processItem(item):
#     return item*10


# # resultArr = []
# # for item in numList:
# #     resultArr.append(processItem(item))

# # print(resultArr)

# resultArr = list(map(processItem, numList))

# print(resultArr)

# ------------------------------------------------- reduce function

numList = [1, 2, 3, 4, 5, 6, 7, 8, 9]


# def processSum(x, y):
#     return x+y

# # sum = functools.reduce(processSum, numList)
# # print(sum)


# sum = functools.reduce(operator.add, numList)
# print("Sum: ", sum)

# pr = functools.reduce(operator.mul, numList)
# print("Product: ", pr)

# maximum = functools.reduce(max, numList)
# print("Max: ", maximum)


def findEven(item):
    return item % 2 == 0


evens = list(filter(findEven, numList))
print(evens)

# evens = filter(findEven, numList)
# for i in evens:
#     print(i)