# def add1(x, y):
#     return x+y


# print(add1(2, 3))


# lambda (x, y): x+y

# ----------------------------------------------------
# def average(callback, *numbers):
#     sum = 0
#     for n in numbers:
#         sum += n

#     if len(numbers):
#         callback(sum/len(numbers))
#     else:
#         callback(sum)


# # Dev 2

# average(lambda result: print("Result is: ", result), 1, 2)
# average(lambda result: print("Result is: ", result), 1, 2, 3, 4, 5)
# average(lambda result: print("Result is: ", result), 1, 2, 3, 4, 5, 6, 7, 8, 9)

# -------------------------------------------------------

# numList = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# resultArr1 = list(map(lambda item: item*10, numList))
# print(resultArr1)

# resultArr2 = list(map(lambda item: item*5, numList))
# print(resultArr2)

# -------------------------------------------------------
numList = [1, 2, 3, 4, 5, 6, 7, 8, 9]

evens = list(filter(lambda item: item % 2 == 0, numList))
print(evens)

odds = list(filter(lambda item: item % 2 == 1, numList))
print(odds)
