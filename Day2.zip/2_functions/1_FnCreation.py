# def hello():
#     pass

# def hello():
#     print('Hello World!')


# hello()
# print(hello)
# print(type(hello))

# ------------------------------------------------
# def add(x, y):
#     return x+y


# print(add(2, 3))
# print(add(2, 3, 4))         # TypeError: add() takes 2 positional arguments but 3 were given
# print(add(2))               # TypeError: add() missing 1 required positional argument: 'y'


# def addAll(numbers):
#     print(numbers)
#     print(type(numbers))


# addAll([1, 2, 3, 4, 5])
# addAll(2)
# addAll(["1", "2"])
# addAll("Manish")
# addAll({"name": "Manish"})
# addAll((2, 3))

def hello(name: str) -> str:
    print(type(name))
    return f"Hello {name}"

hello("Manish")
hello(10)
hello((10, 11))
