# def convert(s):
#     x = int(s)
#     return x

# print(convert("10"))
# print(type(convert("10")))

# print(convert("ab"))
# print("I am the last line")

# -----------------------------------------------

# def convert(s):
#     try:
#         x = int(s)
#         print("Conversion Success")
#     except:
#         x = -1
#         print("Conversion Failed")

#     return x

# def convert(s):
#     try:
#         x = int(s)
#         print("Conversion Success")
#     except Exception as e:
#         x = -1
#         print(e)

#     return x

# def convert(s):
#     try:
#         x = int(s)
#         print("Conversion Success")
#     except ValueError as e:
#         x = -1
#         print(e)
#     except TypeError as e:
#         x = -1
#         print(e)
#     except Exception as e:
#         x = -1
#         print(e)

#     return x

# def convert(s):
#     try:
#         x = int(s)
#         print("Conversion Success")
#     except (ValueError, TypeError) as e:
#         x = -1
#         print(e)
#     except Exception as e:
#         x = 0
#         print(e)

#     return x


# print(convert("10"))
# print(convert("ab"))
# print(convert([10]))
# print("I am the last line")

# -----------------------------------------------
def convert(s):
    try:
        x = int(s)
    except:
        raise Exception("Error Converting Value")

    return x


try:
    print(convert(-1))
except Exception as e:
    print(e)
finally:
    print("Finally Always Runs")

try:
    print(convert([10]))
except Exception as e:
    print(e)
finally:
    print("Finally Always Runs")

print("I am the last line")
