import re
# print(re)
# help(re)

exampleString = '''Riya is 15 years old, and Pravin is 27 years old.
Satish is 97 years old, and his grandfather, Prabhash, is 102.'''

# names = re.findall(r'[A-Z][a-z]*', exampleString)
# names = re.findall(r'\w*\S', exampleString)
# ages = re.findall(r'\d+', exampleString)
# ages = re.findall(r'\d{2}', exampleString)
# ages = re.findall(r'\d{1,3}', exampleString)

# print(names)
# print(ages)

# x = re.search(r"^Riya", exampleString)
# x = re.search(r"\s", exampleString)
# x = re.search(r"\b", exampleString)
# print(x.start())

# x = re.split(r'\s', exampleString)
# print(x)

# -------------------------------------------------------------------
# from urllib.request import urlopen

# with urlopen('http://sixty-north.com/c/t.txt') as story:
#     story_words = []
#     for line in story:
#         line_words = line.decode('utf-8').split()
#         for word in line_words:
#             story_words.append(word)

# with urlopen('http://sixty-north.com/c/t.txt') as story:
#     responseString = story.read().decode('utf-8')
#     story_words = re.split(r'\s', responseString)

# print(story_words)

# -------------------------------------------------------------------
import urllib.request

url = "https://www.google.com/search?q=Synechron"

headers = {}
headers['user-agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36"
req = urllib.request.Request(url, headers=headers)

res = urllib.request.urlopen(req)
respData = res.read()

plaintext = respData.decode('utf-8')

# plaintext = '''<a href="https://www.synechron.com">Synechron | Home</a>
# <a href="https://www.abc.com">ABC | Home</a>'''

# pattern = r'<a[^>]* href="([^"]*)"'
pattern = r'<a[^>]*>(.*?)</a>'

# print(plaintext)

links = re.findall(pattern, plaintext)

for l in links:
    print(l)